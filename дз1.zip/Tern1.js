let a = Math.floor(Math.random() * 100);

let a_h = a;
console.log(`script 1 a = ${a}`);

console.log(`a1 = ${(a > 10 ? a : a * 2) > 5 ? (2 * a) + 1 : (a < 3 ? 1 : 2 * (a - 2)) > 4 ? 5 : (a % 2 == 0 ? 6 : 7)}`);
// условие с условным (тернарным) оператором перевести в if...else И switch()
// результат выводить в консоль, с пощью console.log()


switch (true) {
    case a > 10:
    case a * 2 > 5:
        a = (2 * a) + 1;
        break;
    default:
        switch (true) {
            case a < 3:
                switch (true) {
                    case a % 2 == 0: a = 6;
                        break;
                    default: a = 7;
                }
                break;
            default:
                switch (true) {
                    case 2 * (a - 2) > 4: a = 5;
                        break;
                    default:
                        switch (true) {
                            case a % 2 == 0: a = 6;
                                break;
                            default: a = 7;
                        }
                }
        }
}

console.log(`switch() a2 = ${a}`);








a = a_h;

if ((a > 10) || (a * 2 > 5)) {
    a += a + 1;
}
else {
    if (a < 3) {
        if (1 > 4) {
            a = 5;
        }
        else {
            if (a % 2 == 0) {
                a = 6;
            }
            else { a = 7; }
        }
    }
    else {
        if (2 * (a - 2) > 4) {
            a = 5;
        }
        else {
            if (a % 2 == 0) {
                a = 6;
            }
            else { a = 7; }
        }
    }


}

console.log(`if...else a2 = ${a}`);
