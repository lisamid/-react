//let a = Math.floor(Math.random() * 20) + 1;
console.log(`script 2 a = ${a}`);
function manyChecks(a) {
  
    return (
    a > 10 ? 'a is bigger than 10 ' : 'a is less than or equal to 10 ' + (a === 5 ? 'an example of a special case ' : '')) + (a === 15 ? 'but a is not 15 ' : '')+ (a > 5 ? 'and a is greater than 5 ' : 'and a is less than or equal to 5 ') + (a % 2 ? 'and a is odd ' : 'and a is even ');
}


// условие с условным (тернарным) оператором перевести в if...else И switch()
// результат выводить в консоль, с пощью console.log()

function swith_funk(a) {
    let s = ''
    switch (true) {
        case a > 10: s += 'a is bigger than 10 ';
            break;
        default: s += 'a is less than or equal to 10 ';
    }
    switch (true) {
        case a === 5: s += 'an example of a special case ';
            break;
    }
    switch (true) {
        case a === 15: s += 'but a is not 15 ';
            break;
    }
    switch (true) {
        case a > 5: s += 'and a is greater than 5 ';
            break;
        default: s += 'and a is less than or equal to 5 ';
    }
    switch (true) {
        case a % 2 === 1: s += 'and a is odd ';
            break;
        default: s += 'and a is even ';
    }
    return (s);
}


function if_else(a) {
    let s = '';
    if (a > 10) {
        s += 'a is bigger than 10 ';
    }
    else { s += 'a is less than or equal to 10 '; }

    if (a === 5) {
        s += 'an example of a special case ';
    }

    if (a === 15) {
        s += 'but a is not 15 ';
    }

    if (a > 5) {
        s += 'and a is greater than 5 ';
    }
    else { s += 'and a is less than or equal to 5 '; }

    if (a % 2) {
        s += 'and a is odd '
    }
    else { s += 'and a is even '; }
    return (s);
}

console.log(manyChecks(a));
console.log(swith_funk(a));
console.log(if_else(a));


//for (let i = 0; i < 100; i++) {
//    a = i;
//    console.log(manyChecks(a));
//    console.log(swith_funk(a));
//    console.log(if_else(a));
//}